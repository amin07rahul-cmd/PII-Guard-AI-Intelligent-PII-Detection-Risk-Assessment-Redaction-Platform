const BASE = process.env.REACT_APP_API_BASE || "http://127.0.0.1:8000";

async function request(path, options = {}) {
  const res = await fetch(`${BASE}${path}`, {
    ...options,
    headers: options.body instanceof FormData
      ? options.headers
      : { "Content-Type": "application/json", ...options.headers },
  });
  if (!res.ok) {
    const text = await res.text();
    throw new Error(`${res.status}: ${text}`);
  }
  const contentType = res.headers.get("content-type") || "";
  if (contentType.includes("application/json")) return res.json();
  return res.blob();
}

export const api = {
  uploadDocument: (file, language, department) => {
    const form = new FormData();
    form.append("file", file);
    form.append("language", language);
    if (department) form.append("department", department);
    return request("/api/documents/upload", { method: "POST", body: form });
  },
  listDocuments: () => request("/api/documents"),
  getDocument: (id) => request(`/api/documents/${id}`),
  deleteDocument: (id) => request(`/api/documents/${id}`, { method: "DELETE" }),

  applyRedaction: (payload) =>
    request("/api/redaction/apply", { method: "POST", body: JSON.stringify(payload) }),
  getPolicy: () => request("/api/redaction/policy"),
  setPolicy: (entityType, mode) =>
    request(`/api/redaction/policy/${entityType}?mode=${mode}`, { method: "PUT" }),

  getReport: (id) => request(`/api/reports/${id}`),
  exportReportUrl: (id, fmt) => `${BASE}/api/reports/${id}/export/${fmt}`,

  askCopilot: (question, documentId) =>
    request("/api/copilot/ask", {
      method: "POST",
      body: JSON.stringify({ question, document_id: documentId || null }),
    }),

  analyticsOverview: () => request("/api/analytics/overview"),

  listAlerts: () => request("/api/alerts"),
  acknowledgeAlert: (id) => request(`/api/alerts/${id}/acknowledge`, { method: "POST" }),
  auditLogs: () => request("/api/alerts/audit-logs"),

  login: (email, password) =>
    request("/api/auth/login", { method: "POST", body: JSON.stringify({ email, password }) }),
  register: (email, password, role) =>
    request(`/api/auth/register?role=${role}`, {
      method: "POST",
      body: JSON.stringify({ email, password }),
    }),
};