import React, { useState } from "react";
import UploadPanel from "./components/UploadPanel";
import DocumentWorkspace from "./components/DocumentWorkspace";
import AnalyticsDashboard from "./components/AnalyticsDashboard";
import PrivacyCopilot from "./components/PrivacyCopilot";
import AlertsPanel from "./components/AlertsPanel";
import "./styles/app.css";

const TABS = [
  { id: "input", label: "01 · Input & Detection" },
  { id: "dashboard", label: "11 · Analytics" },
  { id: "copilot", label: "10 · Privacy Copilot" },
  { id: "alerts", label: "12 · Alerts & Audit" },
];

export default function App() {
  const [tab, setTab] = useState("input");
  const [activeDocument, setActiveDocument] = useState(null);

  return (
    <div className="app-shell">
      <header className="app-header">
        <div className="brand">
          <span className="brand-mark" />
          <div>
            <h1>PII GUARD AI</h1>
            <p className="tagline">AI-powered PII detection, risk assessment &amp; redaction</p>
          </div>
        </div>
        <nav className="tabs">
          {TABS.map((t) => (
            <button
              key={t.id}
              className={`tab ${tab === t.id ? "tab-active" : ""}`}
              onClick={() => setTab(t.id)}
            >
              {t.label}
            </button>
          ))}
        </nav>
      </header>

      <main className="app-main">
        {tab === "input" && (
          <div className="input-layout">
            <UploadPanel onProcessed={(doc) => { setActiveDocument(doc); }} />
            <DocumentWorkspace
              activeDocument={activeDocument}
              onSelectDocument={setActiveDocument}
            />
          </div>
        )}
        {tab === "dashboard" && <AnalyticsDashboard />}
        {tab === "copilot" && <PrivacyCopilot activeDocument={activeDocument} />}
        {tab === "alerts" && <AlertsPanel />}
      </main>
    </div>
  );
}
