import React from "react";

export default function PIIDetectionTable({ entities = [] }) {
  if (!entities.length) {
    return <p className="text-secondary" style={{ fontSize: 13 }}>No PII detected yet.</p>;
  }
  return (
    <table className="pii-table">
      <thead>
        <tr>
          <th>Type</th>
          <th>Value</th>
          <th>Risk</th>
          <th>Confidence</th>
          <th>Source</th>
        </tr>
      </thead>
      <tbody>
        {entities.map((e) => (
          <tr key={e.id}>
            <td>{e.entity_type}</td>
            <td className="value">{e.value}</td>
            <td><span className={`badge badge-${e.risk_level}`}>{e.risk_level}</span></td>
            <td>{Math.round(e.confidence * 100)}%</td>
            <td className="text-secondary">{e.source}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
