import React from "react";
import { api } from "../api/client";

export default function ReportPanel({ document }) {
  return (
    <div>
      <span className="redact-label">Module 06</span>
      <h3>Output &amp; Report</h3>
      <p className="text-secondary" style={{ fontSize: 13 }}>
        Export the PII summary, risk score, redaction details and affected pages.
      </p>
      <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
        {["pdf", "json", "csv"].map((fmt) => (
          <a key={fmt} className="btn-ghost" href={api.exportReportUrl(document.id, fmt)}>
            Export {fmt.toUpperCase()}
          </a>
        ))}
      </div>
    </div>
  );
}
