import React, { useEffect, useState } from "react";
import { api } from "../api/client";

export default function AlertsPanel() {
  const [alerts, setAlerts] = useState([]);
  const [logs, setLogs] = useState([]);

  const refresh = () => {
    api.listAlerts().then(setAlerts);
    api.auditLogs().then(setLogs);
  };

  useEffect(() => {
    refresh();
    const id = setInterval(refresh, 15000);
    return () => clearInterval(id);
  }, []);

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
      <div className="panel">
        <span className="redact-label">Module 12</span>
        <h2>Real-time Alerts</h2>
        {alerts.length === 0 && <p className="text-secondary">No alerts raised yet.</p>}
        {alerts.map((a) => (
          <div className="alert-row" key={a._id}>
            <div>
              <span className={`badge badge-${a.severity === "critical" ? "high" : "medium"}`}>{a.severity}</span>
              <span style={{ marginLeft: 10 }}>{a.message}</span>
            </div>
            {!a.acknowledged && (
              <button className="btn-ghost" onClick={async () => { await api.acknowledgeAlert(a._id); refresh(); }}>
                Acknowledge
              </button>
            )}
          </div>
        ))}
      </div>

      <div className="panel">
        <h2>Audit Logs</h2>
        {logs.length === 0 && <p className="text-secondary">No activity recorded yet.</p>}
        {logs.map((l) => (
          <div className="alert-row" key={l.id}>
            <div>
              <span className="mono">{l.action}</span>
              <span className="text-secondary" style={{ marginLeft: 10 }}>
                {new Date(l.created_at).toLocaleString()}
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
