import React from "react";

const COLORS = { "HIGH RISK": "var(--risk-high)", "MEDIUM RISK": "var(--risk-medium)", "LOW RISK": "var(--risk-low)" };

export default function RiskGauge({ score = 0, label = "LOW RISK" }) {
  const angle = (Math.min(Math.max(score, 0), 100) / 100) * 180;
  const needleColor = COLORS[label] || "var(--risk-low)";
  const cx = 100, cy = 100, r = 78;
  const x2 = cx - r * Math.cos((angle * Math.PI) / 180);
  const y2 = cy - r * Math.sin((angle * Math.PI) / 180);

  return (
    <div style={{ textAlign: "center" }}>
      <svg viewBox="0 0 200 120" width="220" height="132">
        <path d="M 20 100 A 80 80 0 0 1 180 100" fill="none" stroke="var(--hairline)" strokeWidth="14" />
        <path d="M 20 100 A 80 80 0 0 1 68 27" fill="none" stroke="var(--risk-low)" strokeWidth="14" />
        <path d="M 68 27 A 80 80 0 0 1 132 27" fill="none" stroke="var(--risk-medium)" strokeWidth="14" />
        <path d="M 132 27 A 80 80 0 0 1 180 100" fill="none" stroke="var(--risk-high)" strokeWidth="14" />
        <line x1={cx} y1={cy} x2={x2} y2={y2} stroke={needleColor} strokeWidth="3" />
        <circle cx={cx} cy={cy} r="5" fill={needleColor} />
      </svg>
      <div style={{ fontFamily: "var(--font-display)", fontSize: 30 }}>{score}<span style={{ fontSize: 16, color: "var(--text-secondary)" }}>/100</span></div>
      <span className="badge" style={{
        background: "transparent", border: `1px solid ${needleColor}`, color: needleColor,
      }}>{label}</span>
    </div>
  );
}
