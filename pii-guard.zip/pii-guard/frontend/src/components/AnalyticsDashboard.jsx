import React, { useEffect, useState } from "react";
import { api } from "../api/client";

export default function AnalyticsDashboard() {
  const [overview, setOverview] = useState(null);

  useEffect(() => {
    api.analyticsOverview().then(setOverview);
    const id = setInterval(() => api.analyticsOverview().then(setOverview), 15000);
    return () => clearInterval(id);
  }, []);

  if (!overview) return <div className="panel">Loading analytics…</div>;

  const maxType = Math.max(1, ...Object.values(overview.pii_by_type));
  const maxDept = Math.max(1, ...Object.values(overview.top_departments));

  return (
    <div className="panel">
      <span className="redact-label">Module 11</span>
      <h2>PII Exposure Overview</h2>

      <div className="stat-grid">
        <div className="stat-card">
          <div className="stat-value">{overview.documents_scanned}</div>
          <div className="stat-label">Documents Scanned</div>
        </div>
        <div className="stat-card">
          <div className="stat-value">{overview.pii_documents}</div>
          <div className="stat-label">PII Documents</div>
        </div>
        <div className="stat-card">
          <div className="stat-value" style={{ color: "var(--risk-high)" }}>{overview.critical}</div>
          <div className="stat-label">Critical</div>
        </div>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24, marginTop: 10 }}>
        <div>
          <h3>PII by Type</h3>
          <div className="bar-chart">
            {Object.entries(overview.pii_by_type).map(([type, count]) => (
              <div className="bar-row" key={type}>
                <span className="mono">{type}</span>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${(count / maxType) * 100}%` }} />
                </div>
                <span>{count}</span>
              </div>
            ))}
            {Object.keys(overview.pii_by_type).length === 0 && (
              <p className="text-secondary">No PII detected across documents yet.</p>
            )}
          </div>
        </div>
        <div>
          <h3>Top Departments</h3>
          <div className="bar-chart">
            {Object.entries(overview.top_departments).map(([dept, count]) => (
              <div className="bar-row" key={dept}>
                <span>{dept}</span>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${(count / maxDept) * 100}%`, background: "var(--risk-medium)" }} />
                </div>
                <span>{count}</span>
              </div>
            ))}
            {Object.keys(overview.top_departments).length === 0 && (
              <p className="text-secondary">No department data yet.</p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
