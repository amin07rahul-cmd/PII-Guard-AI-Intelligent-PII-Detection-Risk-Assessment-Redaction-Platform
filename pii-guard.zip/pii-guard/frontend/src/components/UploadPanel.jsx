import React, { useState } from "react";
import { api } from "../api/client";

const LANGUAGES = [
  { code: "en", label: "English" },
  { code: "hi", label: "Hindi (हिंदी)" },
  { code: "mr", label: "Marathi (मराठी)" },
  { code: "ta", label: "Tamil (தமிழ்)" },
  { code: "bn", label: "Bengali (বাংলা)" },
  { code: "kn", label: "Kannada (ಕನ್ನಡ)" },
];

export default function UploadPanel({ onProcessed }) {
  const [file, setFile] = useState(null);
  const [language, setLanguage] = useState("en");
  const [department, setDepartment] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const handleUpload = async () => {
    if (!file) return;
    setLoading(true);
    setError(null);
    try {
      const doc = await api.uploadDocument(file, language, department);
      onProcessed(doc);
      setFile(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="panel">
      <span className="redact-label">Module 01–02</span>
      <h2>Data Input</h2>
      <p className="text-secondary" style={{ fontSize: 13 }}>
        Accepts Word / DOCX, Excel / CSV, PDF, images / scans, or plain text
        exports. OCR, handwriting recognition and layout analysis run
        automatically for scanned files.
      </p>

      <div
        className="dropzone"
        onDragOver={(e) => e.preventDefault()}
        onDrop={(e) => {
          e.preventDefault();
          if (e.dataTransfer.files[0]) setFile(e.dataTransfer.files[0]);
        }}
      >
        {file ? file.name : "Drag a file here, or click below to browse"}
        <div style={{ marginTop: 10 }}>
          <input
            type="file"
            id="file-input"
            style={{ display: "none" }}
            onChange={(e) => setFile(e.target.files[0])}
          />
          <label htmlFor="file-input" className="btn-ghost" style={{ display: "inline-block" }}>
            Choose file
          </label>
        </div>
      </div>

      <div className="field">
        <label>Document language</label>
        <select value={language} onChange={(e) => setLanguage(e.target.value)}>
          {LANGUAGES.map((l) => (
            <option key={l.code} value={l.code}>{l.label}</option>
          ))}
        </select>
      </div>

      <div className="field">
        <label>Department (optional)</label>
        <input
          type="text"
          placeholder="e.g. HR, Finance, Legal"
          value={department}
          onChange={(e) => setDepartment(e.target.value)}
        />
      </div>

      {error && <p style={{ color: "var(--risk-high)", fontSize: 13 }}>{error}</p>}

      <button className="btn-primary" onClick={handleUpload} disabled={!file || loading}>
        {loading ? "Processing…" : "Upload & Detect PII"}
      </button>
    </div>
  );
}
