import React, { useState } from "react";
import { api } from "../api/client";

const MODES = [
  { value: "full", label: "Full Redaction", example: "████ ████ 9012" },
  { value: "partial", label: "Partial Masking", example: "XXXX XXXX 9012" },
  { value: "show_last4", label: "Show Last 4", example: "XXXXXX3210" },
  { value: "custom_mask", label: "Custom Masking", example: "ra***@gmail.com" },
];

export default function RedactionPanel({ document, onRedacted }) {
  const [mode, setMode] = useState("full");
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  const apply = async () => {
    setLoading(true);
    try {
      const res = await api.applyRedaction({ document_id: document.id, mode });
      setResult(res);
      onRedacted && onRedacted(res);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div>
      <span className="redact-label">Module 05</span>
      <h3>Smart Redaction Engine</h3>
      <div className="field">
        <label>Redaction mode</label>
        <select value={mode} onChange={(e) => setMode(e.target.value)}>
          {MODES.map((m) => (
            <option key={m.value} value={m.value}>{m.label} — {m.example}</option>
          ))}
        </select>
      </div>
      <button className="btn-primary" onClick={apply} disabled={loading}>
        {loading ? "Redacting…" : "Apply Redaction"}
      </button>

      {result && (
        <div style={{ marginTop: 16 }}>
          <span className="redact-label">Module 09</span>
          <h3 style={{ marginTop: 6 }}>Privacy Verification</h3>
          <div className="stat-grid">
            <div className="stat-card">
              <div className="stat-value">{result.pii_found_initial}</div>
              <div className="stat-label">PII found initially</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{result.pii_after_redaction}</div>
              <div className="stat-label">PII after redaction</div>
            </div>
            <div className="stat-card">
              <div className="stat-value">{result.redaction_accuracy}%</div>
              <div className="stat-label">Redaction accuracy</div>
            </div>
            <div className="stat-card">
              <div className="stat-value" style={{
                color: result.verification_status === "PASSED" ? "var(--risk-low)" : "var(--risk-medium)",
                fontSize: 16,
              }}>
                {result.verification_status}
              </div>
              <div className="stat-label">Status</div>
            </div>
          </div>
          {result.redacted_file_url && (
            <a className="btn-ghost" style={{ display: "inline-block", marginTop: 8 }}
               href={result.redacted_file_url} target="_blank" rel="noreferrer">
              Download redacted document
            </a>
          )}
        </div>
      )}
    </div>
  );
}
