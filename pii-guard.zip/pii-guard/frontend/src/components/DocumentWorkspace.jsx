import React, { useEffect, useState, useCallback } from "react";
import { api } from "../api/client";
import PIIDetectionTable from "./PIIDetectionTable";
import RiskGauge from "./RiskGauge";
import RedactionPanel from "./RedactionPanel";
import ReportPanel from "./ReportPanel";

export default function DocumentWorkspace({ activeDocument, onSelectDocument }) {
  const [documents, setDocuments] = useState([]);
  const [detail, setDetail] = useState(null);
  const [redactionResult, setRedactionResult] = useState(null);

  const refreshList = useCallback(async () => {
    const docs = await api.listDocuments();
    setDocuments(docs);
  }, []);

  useEffect(() => { refreshList(); }, [refreshList, activeDocument]);

  useEffect(() => {
    if (activeDocument?.id) {
      api.getDocument(activeDocument.id).then(setDetail);
      setRedactionResult(null);
    }
  }, [activeDocument]);

  return (
    <div className="panel">
      <span className="redact-label">Modules 03–09</span>
      <h2>Detection, Risk &amp; Redaction Workspace</h2>

      <div className="section-divider">
        <h3>Documents</h3>
      </div>
      <ul className="doc-list">
        {documents.map((d) => (
          <li
            key={d.id}
            className={detail?.id === d.id ? "active" : ""}
            onClick={() => onSelectDocument(d)}
          >
            <span>{d.filename} <span className="text-secondary mono">({d.language})</span></span>
            <span className="text-secondary">{d.status}</span>
          </li>
        ))}
        {documents.length === 0 && <li className="text-secondary">No documents uploaded yet.</li>}
      </ul>

      {detail && (
        <>
          <div className="section-divider">
            <span className="redact-label">Module 04</span>
            <h3>Risk Assessment</h3>
          </div>
          <div className="gauge-wrap">
            {detail.risk_assessment ? (
              <>
                <RiskGauge score={detail.risk_assessment.risk_score} label={detail.risk_assessment.risk_label} />
                <div className="stat-grid" style={{ flex: 1 }}>
                  <div className="stat-card">
                    <div className="stat-value">{detail.risk_assessment.pii_count}</div>
                    <div className="stat-label">PII Count</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-value" style={{ color: "var(--risk-high)" }}>{detail.risk_assessment.high_risk_items}</div>
                    <div className="stat-label">High Risk</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-value" style={{ color: "var(--risk-medium)" }}>{detail.risk_assessment.medium_risk_items}</div>
                    <div className="stat-label">Medium Risk</div>
                  </div>
                  <div className="stat-card">
                    <div className="stat-value" style={{ color: "var(--risk-low)" }}>{detail.risk_assessment.low_risk_items}</div>
                    <div className="stat-label">Low Risk</div>
                  </div>
                </div>
              </>
            ) : <p className="text-secondary">Not yet assessed.</p>}
          </div>
          {detail.risk_assessment?.risk_factors?.length > 0 && (
            <p className="text-secondary" style={{ fontSize: 13 }}>
              Risk factors: <span className="mono">{detail.risk_assessment.risk_factors.join(", ")}</span>
            </p>
          )}

          <div className="section-divider">
            <span className="redact-label">Module 03 / 08</span>
            <h3>Detected PII</h3>
          </div>
          <PIIDetectionTable entities={detail.pii_entities} />

          <div className="section-divider">
            <RedactionPanel document={detail} onRedacted={setRedactionResult} />
          </div>

          <div className="section-divider">
            <ReportPanel document={detail} />
          </div>
        </>
      )}
    </div>
  );
}
