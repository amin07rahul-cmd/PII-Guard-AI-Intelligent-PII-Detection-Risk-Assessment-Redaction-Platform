import React, { useState, useRef, useEffect } from "react";
import { api } from "../api/client";

export default function PrivacyCopilot({ activeDocument }) {
  const [messages, setMessages] = useState([
    { role: "bot", text: "Ask me things like \"Find all documents with Aadhaar numbers\" or \"Why is this document high risk?\"" },
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight });
  }, [messages]);

  const send = async () => {
    if (!input.trim()) return;
    const question = input.trim();
    setMessages((m) => [...m, { role: "user", text: question }]);
    setInput("");
    setLoading(true);
    try {
      const res = await api.askCopilot(question, activeDocument?.id);
      setMessages((m) => [...m, { role: "bot", text: res.answer }]);
    } catch (e) {
      setMessages((m) => [...m, { role: "bot", text: "Something went wrong answering that." }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="panel" style={{ maxWidth: 720 }}>
      <span className="redact-label">Module 10</span>
      <h2>Privacy Copilot</h2>
      {activeDocument && (
        <p className="text-secondary" style={{ fontSize: 12 }}>
          Context: <span className="mono">{activeDocument.filename}</span>
        </p>
      )}
      <div className="chat-window scrollbar-thin" ref={scrollRef}>
        {messages.map((m, i) => (
          <div key={i} className={`chat-msg ${m.role === "user" ? "user" : "bot"}`}>
            <div className="chat-bubble">{m.text}</div>
          </div>
        ))}
        {loading && <div className="chat-msg bot"><div className="chat-bubble">Thinking…</div></div>}
      </div>
      <div style={{ display: "flex", gap: 8 }}>
        <input
          type="text"
          style={{ flex: 1 }}
          value={input}
          placeholder="Ask a privacy question…"
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && send()}
        />
        <button className="btn-primary" onClick={send} disabled={loading}>Ask</button>
      </div>
    </div>
  );
}
