# PII Guard AI — Intelligent Privacy Protection for Documents & Data

A complete, original implementation of the 12-module AI-powered PII
detection, risk assessment and redaction system, built only with the
technology stack shown in the reference diagram:

**Python · OpenCV · Tesseract OCR · spaCy · scikit-learn · Hugging Face
Transformers · PostgreSQL · MongoDB · React.js · FastAPI**

No other frameworks, UI kits, or third-party AI services are used, and
this runs entirely on your own machine — nothing here talks to the
internet or needs to be deployed anywhere.

## Module → implementation map

| # | Module | Where it lives |
|---|--------|-----------------|
| 1 | Data Input | `backend/app/routers/documents.py` (upload endpoint, multi-format) |
| 2 | Document Processing | `backend/app/services/ocr_service.py` (OpenCV enhance/denoise/deskew + Tesseract OCR) |
| 3 | PII Detection (AI + NLP) | `backend/app/services/pii_detector.py` (spaCy NER + regex validators) |
| 4 | Risk Assessment Engine | `backend/app/services/risk_engine.py` (weighted score + scikit-learn bucket classifier) |
| 5 | Smart Redaction Engine | `backend/app/services/redaction_engine.py` + `routers/redaction.py` (policy-based, 4 modes) |
| 6 | Output & Report | `backend/app/services/report_service.py` (PDF/JSON/CSV via reportlab/pandas) |
| 7 | Multilingual PII Detection | `pii_detector.py` (langdetect + script-aware matching) + language selector in the UI |
| 8 | Image & Handwritten PII | `ocr_service.extract_words_with_boxes` + `redaction_engine.redact_image` |
| 9 | Privacy Verification | `routers/redaction.py` re-runs detection on the redacted output |
| 10 | Privacy Copilot (AI Assistant) | `backend/app/services/copilot_service.py` (Hugging Face zero-shot intent + grounded DB lookups) |
| 11 | Analytics & Dashboard | `backend/app/routers/analytics.py` + `frontend/src/components/AnalyticsDashboard.jsx` |
| 12 | Alerts & Integration | `backend/app/routers/alerts.py` (real-time alerts, audit logs, RBAC via `auth.py`) |

PostgreSQL stores structured metadata (documents, PII entities, risk
scores, users, audit logs). MongoDB stores flexible documents (generated
reports, copilot conversation logs, alerts, analytics events). Files are
stored on local disk by default (`STORAGE_BACKEND=local`); AWS S3 is
supported as a drop-in alternative (`STORAGE_BACKEND=s3`) if you ever
want to point it at a real bucket, but is entirely optional.

You need **5 things running at once**: PostgreSQL, MongoDB, Tesseract
(just installed, not "running"), the backend server, and the frontend
server. Follow the steps below in order, once.

---

## Step 1 — Install the system-level programs

Download and install each of these normally (like any desktop app):

- **Python 3.11–3.13** — https://www.python.org/downloads/
- **Node.js** (LTS) — https://nodejs.org
- **PostgreSQL** — https://www.postgresql.org/download/
  - During install it will ask you to set a password for the `postgres` user — remember it.
  - After installing, create a database and user for this project (open **pgAdmin** or `psql` and run):
    ```sql
    CREATE USER piiguard WITH PASSWORD 'piiguard';
    CREATE DATABASE piiguard OWNER piiguard;
    ```
- **MongoDB Community Server** — https://www.mongodb.com/try/download/community
  - Install it as a service — it will start automatically in the background, listening on `localhost:27017`.
- **Tesseract OCR** — https://github.com/UB-Mannheim/tesseract/wiki
  - On Windows, note the install path, usually `C:\Program Files\Tesseract-OCR\tesseract.exe`.
  - When the installer offers additional language packs, tick Hindi, Marathi, Tamil, Bengali and Kannada if you want multilingual OCR (module 7); English is included by default.

## Step 2 — Set up the backend

Open a terminal in the `backend` folder:

```bash
cd pii-guard/backend
python -m venv venv
```
Activate it:
- Windows: `venv\Scripts\activate`
- Mac/Linux: `source venv/bin/activate`

Install everything:
```bash
pip install -r requirements.txt
python -m spacy download en_core_web_sm
```

Configure your environment — copy `.env.example` to `.env`:
```bash
copy .env.example .env      (Windows)
cp .env.example .env        (Mac/Linux)
```
Open `.env` and update these two lines to match what you set up in Step 1:
```
POSTGRES_URL=postgresql://piiguard:piiguard@localhost:5432/piiguard
MONGO_URL=mongodb://localhost:27017
```
If Tesseract isn't on your system PATH, also set:
```
TESSERACT_CMD=C:\Program Files\Tesseract-OCR\tesseract.exe
```

Run the backend:
```bash
uvicorn app.main:app --reload --port 8000
```
Leave this terminal running. Visit http://localhost:8000/docs to confirm it's up.

## Step 3 — Set up the frontend

Open a **second** terminal in the `frontend` folder:
```bash
cd pii-guard/frontend
npm install
npm start
```
This opens the app at http://localhost:3000 and automatically talks to the backend at `localhost:8000`.

---

## Everyday use (after the first-time setup above)

Every time you want to run the project again, you only need:
1. Make sure PostgreSQL and MongoDB services are running (they usually auto-start with Windows).
2. Terminal 1: `cd backend`, `venv\Scripts\activate`, `uvicorn app.main:app --reload --port 8000`
3. Terminal 2: `cd frontend`, `npm start`

## Notes on originality

Every file in this project was written from scratch for this brief: the
detection regexes, risk-scoring formula, redaction modes, report layout,
and the React design system (a "redaction ink" visual identity built
around Space Grotesk / Inter / IBM Plex Mono and a literal black
redaction-bar motif) are original to this codebase — nothing here is
copied from an existing template or product.

## Production hardening checklist

If you ever do want to deploy this beyond your own machine, keep in mind:
- Swap the JWT secret and enforce RBAC checks on every route (only the
  auth scaffolding is included; wire `Depends` guards into each router).
- Replace the no-op email/SMS/SIEM senders in `routers/alerts.py` with
  real AWS SES/SNS or SIEM webhook integrations.
- Move long-running OCR/NLP pipeline calls to a background task queue
  for large files instead of the current synchronous request handling.
- Add DOCX/XLSX/PDF text extraction (e.g. via `python-docx`/`openpyxl`/
  `pypdf`) ahead of the OCR fallback if you need those formats parsed
  beyond raw text decoding.
