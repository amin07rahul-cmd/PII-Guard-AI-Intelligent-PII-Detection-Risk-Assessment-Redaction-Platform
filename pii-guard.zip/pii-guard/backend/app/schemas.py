from typing import Optional, List, Any
from pydantic import BaseModel


class PIIEntityOut(BaseModel):
    id: str
    entity_type: str
    value: str
    risk_level: str
    confidence: float
    page_number: int
    bbox: Optional[List[float]] = None
    source: str

    class Config:
        from_attributes = True


class RiskAssessmentOut(BaseModel):
    risk_score: int
    risk_label: str
    pii_count: int
    high_risk_items: int
    medium_risk_items: int
    low_risk_items: int
    risk_factors: Optional[List[str]] = None

    class Config:
        from_attributes = True


class DocumentOut(BaseModel):
    id: str
    filename: str
    file_type: str
    language: str
    ocr_used: bool
    status: str

    class Config:
        from_attributes = True


class DocumentDetail(DocumentOut):
    extracted_text: Optional[str] = None
    pii_entities: List[PIIEntityOut] = []
    risk_assessment: Optional[RiskAssessmentOut] = None


class RedactionRequest(BaseModel):
    document_id: str
    mode: str = "full"                 # full, partial, show_last4, custom_mask
    entity_types: Optional[List[str]] = None  # restrict redaction to these types; None = all


class RedactionOut(BaseModel):
    document_id: str
    mode: str
    pii_found_initial: int
    pii_after_redaction: int
    redaction_accuracy: float
    verification_status: str
    redacted_file_url: Optional[str] = None


class CopilotQuery(BaseModel):
    question: str
    document_id: Optional[str] = None  # if omitted, searches across all documents


class CopilotResponse(BaseModel):
    answer: str
    matched_documents: List[str] = []
    data: Optional[Any] = None


class AlertOut(BaseModel):
    id: str
    severity: str
    message: str
    document_id: Optional[str]
    created_at: str


class LoginRequest(BaseModel):
    email: str
    password: str


class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"
    role: str
