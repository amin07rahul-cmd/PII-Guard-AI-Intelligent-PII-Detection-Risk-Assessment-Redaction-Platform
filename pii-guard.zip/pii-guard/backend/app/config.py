"""
Central configuration for PII Guard backend.
All values are overridable via environment variables / .env file.
"""
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    APP_NAME: str = "PII Guard AI"
    ENV: str = "development"

    # PostgreSQL - structured metadata (documents, users, audit logs, risk scores)
    POSTGRES_URL: str = "postgresql://piiguard:piiguard@localhost:5432/piiguard"

    # MongoDB - unstructured / flexible report + PII entity storage
    MONGO_URL: str = "mongodb://localhost:27017"
    MONGO_DB: str = "piiguard"

    # Storage backend: "local" or "s3"
    STORAGE_BACKEND: str = "local"
    LOCAL_STORAGE_DIR: str = "./storage"

    # AWS S3 (used only when STORAGE_BACKEND=s3)
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_REGION: str = "ap-south-1"
    S3_BUCKET: str = "pii-guard-documents"

    # Auth
    JWT_SECRET: str = "change-me-in-production"
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 480

    # spaCy models per supported language (module 7: multilingual PII detection)
    SPACY_MODEL_EN: str = "en_core_web_sm"

    # OCR
    TESSERACT_CMD: str = ""  # leave empty to use system PATH tesseract

    class Config:
        env_file = ".env"


settings = Settings()
