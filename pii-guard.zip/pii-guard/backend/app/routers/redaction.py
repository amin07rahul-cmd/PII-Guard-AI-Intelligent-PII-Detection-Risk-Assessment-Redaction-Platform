import os

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Document, PIIEntity, RedactionResult, RedactionPolicy, AuditLog
from app.schemas import RedactionRequest, RedactionOut
from app.services import storage_service, ocr_service, pii_detector
from app.services.redaction_engine import redact_text, redact_image, default_policy, MODES

router = APIRouter(prefix="/api/redaction", tags=["redaction"])


def _policy_map(db: Session) -> dict[str, str]:
    rows = db.query(RedactionPolicy).filter(RedactionPolicy.is_active == True).all()  # noqa: E712
    policy = default_policy()
    for r in rows:
        policy[r.entity_type] = r.mode
    return policy


@router.post("/apply", response_model=RedactionOut)
def apply_redaction(payload: RedactionRequest, db: Session = Depends(get_db)):
    if payload.mode not in MODES:
        raise HTTPException(400, f"mode must be one of {MODES}")

    document = db.query(Document).filter(Document.id == payload.document_id).first()
    if not document:
        raise HTTPException(404, "Document not found")

    entities = db.query(PIIEntity).filter(PIIEntity.document_id == document.id).all()
    entity_dicts = [{"entity_type": e.entity_type, "value": e.value} for e in entities]
    pii_found_initial = len(entity_dicts)

    policy = _policy_map(db)
    if payload.mode:
        # explicit request mode overrides the per-type policy default, but the
        # per-type policy still wins for types not explicitly requested when
        # entity_types is None (module 5: "Auto apply organization defined
        # policies for each PII type").
        for etype in policy:
            policy[etype] = payload.mode

    raw = storage_service.read_bytes(document.storage_path)

    if document.file_type == "image":
        words = ocr_service.extract_words_with_boxes(raw, language=document.language)
        pii_values = {e.value for e in entities
                      if not payload.entity_types or e.entity_type in payload.entity_types}
        redacted_bytes = redact_image(raw, words, pii_values)
        redacted_text = None
    else:
        redacted_text = redact_text(document.extracted_text or "", entity_dicts, policy,
                                     default_mode=payload.mode, entity_types=payload.entity_types)
        redacted_bytes = redacted_text.encode("utf-8")

    redacted_path = storage_service.save_bytes(redacted_bytes, f"redacted_{document.filename}")

    # Module 9: Privacy verification - re-run detection on the redacted output
    # to confirm no PII identifiers remain.
    if document.file_type == "image":
        verify_text = ocr_service.extract_text(redacted_bytes, language=document.language)
    else:
        verify_text = redacted_text or ""
    remaining_entities, _ = pii_detector.detect_pii(verify_text, language=document.language)
    pii_after = len(remaining_entities)
    accuracy = round(100.0 * (1 - (pii_after / pii_found_initial)), 2) if pii_found_initial else 100.0
    status_label = "PASSED" if pii_after == 0 else "REVIEW REQUIRED"

    existing = db.query(RedactionResult).filter(RedactionResult.document_id == document.id).first()
    if existing:
        db.delete(existing)
        db.flush()

    result = RedactionResult(
        document_id=document.id,
        mode=payload.mode,
        redacted_storage_path=redacted_path,
        pii_found_initial=pii_found_initial,
        pii_after_redaction=pii_after,
        redaction_accuracy=accuracy,
        verification_status=status_label,
    )
    db.add(result)
    document.status = "verified" if status_label == "PASSED" else "redacted"
    db.add(AuditLog(action="REDACT", document_id=document.id,
                     details={"mode": payload.mode, "accuracy": accuracy, "status": status_label}))
    db.commit()

    return RedactionOut(
        document_id=document.id,
        mode=payload.mode,
        pii_found_initial=pii_found_initial,
        pii_after_redaction=pii_after,
        redaction_accuracy=accuracy,
        verification_status=status_label,
        redacted_file_url=storage_service.resolve_url(redacted_path),
    )


@router.get("/policy")
def get_policy(db: Session = Depends(get_db)):
    return _policy_map(db)


@router.put("/policy/{entity_type}")
def set_policy(entity_type: str, mode: str, db: Session = Depends(get_db)):
    if mode not in MODES:
        raise HTTPException(400, f"mode must be one of {MODES}")
    row = db.query(RedactionPolicy).filter(RedactionPolicy.entity_type == entity_type).first()
    if row:
        row.mode = mode
    else:
        row = RedactionPolicy(entity_type=entity_type, mode=mode)
        db.add(row)
    db.commit()
    return {"entity_type": entity_type, "mode": mode}
