from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import Response
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Document, PIIEntity, RiskAssessment, RedactionResult, AuditLog
from app.mongo import reports_collection
from app.services import report_service

router = APIRouter(prefix="/api/reports", tags=["reports"])


def _build(db: Session, document_id: str) -> dict:
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(404, "Document not found")
    entities = db.query(PIIEntity).filter(PIIEntity.document_id == document_id).all()
    entity_dicts = [{
        "entity_type": e.entity_type, "value": e.value, "risk_level": e.risk_level,
        "confidence": e.confidence, "page_number": e.page_number, "source": e.source,
    } for e in entities]
    risk = db.query(RiskAssessment).filter(RiskAssessment.document_id == document_id).first()
    risk_dict = {
        "risk_score": risk.risk_score, "risk_label": risk.risk_label,
        "risk_factors": risk.risk_factors,
    } if risk else None
    redaction = db.query(RedactionResult).filter(RedactionResult.document_id == document_id).first()
    report = report_service.build_report_dict(document, risk_dict, redaction, entity_dicts)

    reports_collection.update_one({"document_id": document_id}, {"$set": report}, upsert=True)
    db.add(AuditLog(action="EXPORT", document_id=document_id, details={"format": "generated"}))
    db.commit()
    return report


@router.get("/{document_id}")
def get_report(document_id: str, db: Session = Depends(get_db)):
    return _build(db, document_id)


@router.get("/{document_id}/export/{fmt}")
def export_report(document_id: str, fmt: str, db: Session = Depends(get_db)):
    report = _build(db, document_id)
    if fmt == "json":
        return Response(report_service.to_json_bytes(report), media_type="application/json",
                         headers={"Content-Disposition": f"attachment; filename=report_{document_id}.json"})
    if fmt == "csv":
        return Response(report_service.to_csv_bytes(report), media_type="text/csv",
                         headers={"Content-Disposition": f"attachment; filename=report_{document_id}.csv"})
    if fmt == "pdf":
        return Response(report_service.to_pdf_bytes(report), media_type="application/pdf",
                         headers={"Content-Disposition": f"attachment; filename=report_{document_id}.pdf"})
    raise HTTPException(400, "format must be json, csv or pdf")
