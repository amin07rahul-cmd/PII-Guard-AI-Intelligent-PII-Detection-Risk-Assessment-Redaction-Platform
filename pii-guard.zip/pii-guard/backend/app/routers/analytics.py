from collections import Counter

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Document, PIIEntity, RiskAssessment

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/overview")
def overview(db: Session = Depends(get_db)):
    """PII Exposure Overview: documents scanned, PII documents, critical count,
    PII by type, top departments by PII volume - powers module 11's dashboard."""
    total_documents = db.query(Document).count()

    docs_with_pii = (db.query(PIIEntity.document_id).distinct().count())

    critical = (db.query(RiskAssessment)
                .filter(RiskAssessment.risk_label == "HIGH RISK").count())

    entities = db.query(PIIEntity.entity_type).all()
    pii_by_type = dict(Counter(e[0] for e in entities))

    dept_rows = (db.query(Document.department, PIIEntity.id)
                 .join(PIIEntity, PIIEntity.document_id == Document.id).all())
    dept_counter = Counter(d or "Unassigned" for d, _ in dept_rows)
    top_departments = dict(sorted(dept_counter.items(), key=lambda kv: kv[1], reverse=True)[:6])

    return {
        "documents_scanned": total_documents,
        "pii_documents": docs_with_pii,
        "critical": critical,
        "pii_by_type": pii_by_type,
        "top_departments": top_departments,
    }
