from typing import Optional

from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import Document, AuditLog
from app.schemas import DocumentOut, DocumentDetail
from app.services import storage_service
from app.services.pipeline import run_pipeline

router = APIRouter(prefix="/api/documents", tags=["documents"])

ALLOWED_TYPES = {
    ".pdf": "pdf", ".docx": "docx", ".doc": "docx", ".xlsx": "xlsx", ".xls": "xlsx",
    ".csv": "csv", ".txt": "text", ".png": "image", ".jpg": "image", ".jpeg": "image",
    ".tif": "image", ".tiff": "image", ".bmp": "image",
}


def _file_type(filename: str) -> str:
    for ext, ftype in ALLOWED_TYPES.items():
        if filename.lower().endswith(ext):
            return ftype
    return "unknown"


@router.post("/upload", response_model=DocumentDetail)
async def upload_document(
    file: UploadFile = File(...),
    language: str = Form("en"),
    department: Optional[str] = Form(None),
    db: Session = Depends(get_db),
):
    """Module 1: Data Input - accepts PDF, Word/DOCX, Excel/CSV, image/scanned,
    or plain text/database exports. Runs the full processing -> detection ->
    risk-assessment pipeline (modules 2-4) synchronously and returns the result."""
    ftype = _file_type(file.filename)
    if ftype == "unknown":
        raise HTTPException(400, "Unsupported file type")

    raw = await file.read()
    storage_path = storage_service.save_bytes(raw, file.filename)

    document = Document(
        filename=file.filename,
        file_type=ftype,
        storage_path=storage_path,
        language=language,
        department=department,
    )
    db.add(document)
    db.commit()
    db.refresh(document)

    run_pipeline(db, document, raw)

    db.add(AuditLog(action="UPLOAD", document_id=document.id,
                     details={"filename": file.filename, "file_type": ftype}))
    db.commit()
    db.refresh(document)
    return document


@router.get("", response_model=list[DocumentOut])
def list_documents(db: Session = Depends(get_db)):
    return db.query(Document).order_by(Document.created_at.desc()).all()


@router.get("/{document_id}", response_model=DocumentDetail)
def get_document(document_id: str, db: Session = Depends(get_db)):
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(404, "Document not found")
    return document


@router.delete("/{document_id}")
def delete_document(document_id: str, db: Session = Depends(get_db)):
    document = db.query(Document).filter(Document.id == document_id).first()
    if not document:
        raise HTTPException(404, "Document not found")
    db.delete(document)
    db.commit()
    return {"status": "deleted"}
