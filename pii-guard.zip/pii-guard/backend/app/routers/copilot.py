from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.mongo import copilot_logs_collection
from app.schemas import CopilotQuery, CopilotResponse
from app.services import copilot_service

router = APIRouter(prefix="/api/copilot", tags=["copilot"])


@router.post("/ask", response_model=CopilotResponse)
def ask(payload: CopilotQuery, db: Session = Depends(get_db)):
    result = copilot_service.answer_question(payload.question, db, document_id=payload.document_id)
    copilot_logs_collection.insert_one({
        "question": payload.question,
        "document_id": payload.document_id,
        "answer": result["answer"],
    })
    return CopilotResponse(**result)
