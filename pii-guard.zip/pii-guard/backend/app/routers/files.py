import os

from fastapi import APIRouter, HTTPException
from fastapi.responses import FileResponse

from app.config import settings

router = APIRouter(prefix="/api/files", tags=["files"])


@router.get("/{filename}")
def get_file(filename: str):
    if settings.STORAGE_BACKEND != "local":
        raise HTTPException(400, "Direct file serving only applies to local storage backend")
    path = os.path.join(settings.LOCAL_STORAGE_DIR, filename)
    if not os.path.isfile(path):
        raise HTTPException(404, "File not found")
    return FileResponse(path)
