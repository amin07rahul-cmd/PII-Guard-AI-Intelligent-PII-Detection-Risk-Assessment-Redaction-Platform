"""
Module 12: Alerts & Integration.
Raises a real-time alert whenever a document is assessed as HIGH RISK, and
exposes an audit-log endpoint for compliance review. Email/SMS/SIEM
notification channels are implemented as pluggable no-op senders here -
swap in a real provider (SES/SNS/Slack webhook/SIEM syslog) in production
without changing the calling code.
"""
from datetime import datetime

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.database import get_db
from app.models import AuditLog
from app.mongo import alerts_collection

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


def raise_alert(document_id: str, severity: str, message: str):
    alerts_collection.insert_one({
        "document_id": document_id,
        "severity": severity,
        "message": message,
        "created_at": datetime.utcnow().isoformat(),
        "acknowledged": False,
    })
    _notify_email_sms(message)
    _notify_siem(document_id, severity, message)


def _notify_email_sms(message: str):
    # Plug in AWS SES / SNS or a similar provider here.
    pass


def _notify_siem(document_id: str, severity: str, message: str):
    # Plug in a SIEM/DLP syslog or webhook integration here.
    pass


@router.get("")
def list_alerts(limit: int = 50):
    docs = list(alerts_collection.find().sort("created_at", -1).limit(limit))
    for d in docs:
        d["_id"] = str(d["_id"])
    return docs


@router.post("/{alert_id}/acknowledge")
def acknowledge(alert_id: str):
    from bson import ObjectId
    alerts_collection.update_one({"_id": ObjectId(alert_id)}, {"$set": {"acknowledged": True}})
    return {"status": "acknowledged"}


@router.get("/audit-logs")
def audit_logs(db: Session = Depends(get_db), limit: int = 100):
    rows = db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).all()
    return [{
        "id": r.id, "action": r.action, "document_id": r.document_id,
        "details": r.details, "created_at": r.created_at.isoformat(),
    } for r in rows]
