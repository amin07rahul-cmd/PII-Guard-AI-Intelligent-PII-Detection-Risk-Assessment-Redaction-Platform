import uuid
from datetime import datetime

from sqlalchemy import (Column, String, Integer, Float, DateTime, ForeignKey,
                         Text, Boolean, JSON)
from sqlalchemy.orm import relationship

from app.database import Base


def gen_id():
    return str(uuid.uuid4())


class User(Base):
    """Module 12: Role Based Access Control"""
    __tablename__ = "users"

    id = Column(String, primary_key=True, default=gen_id)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    role = Column(String, default="viewer")  # admin, analyst, viewer
    department = Column(String, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)


class Document(Base):
    """Module 1-2: Data input + document processing metadata"""
    __tablename__ = "documents"

    id = Column(String, primary_key=True, default=gen_id)
    filename = Column(String, nullable=False)
    file_type = Column(String, nullable=False)          # pdf, docx, xlsx, csv, image, db/text
    storage_path = Column(String, nullable=False)
    uploaded_by = Column(String, ForeignKey("users.id"), nullable=True)
    department = Column(String, nullable=True)
    language = Column(String, default="en")             # module 7: multilingual
    ocr_used = Column(Boolean, default=False)            # module 2/8
    extracted_text = Column(Text, nullable=True)
    status = Column(String, default="uploaded")          # uploaded/processing/detected/redacted/verified
    created_at = Column(DateTime, default=datetime.utcnow)

    pii_entities = relationship("PIIEntity", back_populates="document", cascade="all, delete-orphan")
    risk_assessment = relationship("RiskAssessment", back_populates="document", uselist=False,
                                    cascade="all, delete-orphan")
    redaction = relationship("RedactionResult", back_populates="document", uselist=False,
                              cascade="all, delete-orphan")


class PIIEntity(Base):
    """Module 3 & 8: PII detection (text + image/handwritten)"""
    __tablename__ = "pii_entities"

    id = Column(String, primary_key=True, default=gen_id)
    document_id = Column(String, ForeignKey("documents.id"), nullable=False)
    entity_type = Column(String, nullable=False)   # NAME, AADHAAR, PAN, PHONE, EMAIL, ADDRESS, DOB
    value = Column(String, nullable=False)
    risk_level = Column(String, default="low")     # high/medium/low
    confidence = Column(Float, default=0.9)
    page_number = Column(Integer, default=1)
    bbox = Column(JSON, nullable=True)             # [x, y, w, h] for image/handwritten PII (module 8)
    source = Column(String, default="regex")       # regex, spacy_ner, ocr

    document = relationship("Document", back_populates="pii_entities")


class RiskAssessment(Base):
    """Module 4: Risk assessment engine"""
    __tablename__ = "risk_assessments"

    id = Column(String, primary_key=True, default=gen_id)
    document_id = Column(String, ForeignKey("documents.id"), unique=True, nullable=False)
    risk_score = Column(Integer, default=0)         # 0-100
    risk_label = Column(String, default="LOW RISK")
    pii_count = Column(Integer, default=0)
    high_risk_items = Column(Integer, default=0)
    medium_risk_items = Column(Integer, default=0)
    low_risk_items = Column(Integer, default=0)
    risk_factors = Column(JSON, nullable=True)      # e.g. ["Aadhaar", "PAN", "Phone", "Address"]
    computed_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="risk_assessment")


class RedactionResult(Base):
    """Module 5: Smart redaction engine"""
    __tablename__ = "redaction_results"

    id = Column(String, primary_key=True, default=gen_id)
    document_id = Column(String, ForeignKey("documents.id"), unique=True, nullable=False)
    mode = Column(String, default="full")           # full, partial, show_last4, custom_mask
    redacted_storage_path = Column(String, nullable=True)
    pii_found_initial = Column(Integer, default=0)
    pii_after_redaction = Column(Integer, default=0)
    redaction_accuracy = Column(Float, default=0.0)
    verification_status = Column(String, default="PENDING")  # module 9: privacy verification
    created_at = Column(DateTime, default=datetime.utcnow)

    document = relationship("Document", back_populates="redaction")


class RedactionPolicy(Base):
    """Organization-defined per-PII-type redaction policy (used by module 5's policy engine)"""
    __tablename__ = "redaction_policies"

    id = Column(String, primary_key=True, default=gen_id)
    entity_type = Column(String, unique=True, nullable=False)
    mode = Column(String, default="full")           # full, partial, show_last4, custom_mask
    is_active = Column(Boolean, default=True)


class AuditLog(Base):
    """Module 12: Audit logs & compliance"""
    __tablename__ = "audit_logs"

    id = Column(String, primary_key=True, default=gen_id)
    user_id = Column(String, ForeignKey("users.id"), nullable=True)
    action = Column(String, nullable=False)         # UPLOAD, DETECT, REDACT, EXPORT, VIEW
    document_id = Column(String, nullable=True)
    details = Column(JSON, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
