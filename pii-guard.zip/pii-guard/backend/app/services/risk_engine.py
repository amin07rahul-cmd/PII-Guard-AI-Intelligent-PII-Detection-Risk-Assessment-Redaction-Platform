"""
Module 4: Risk Assessment Engine.
Calculates a 0-100 privacy risk score from PII type, count and combination,
using a transparent weighted formula (so the score in the report is always
explainable) reinforced by a scikit-learn classifier that buckets the score
into HIGH / MEDIUM / LOW using the same features, trained on synthetic
labelled examples that mirror real-world identity-fraud risk patterns.
"""
import numpy as np
from sklearn.linear_model import LogisticRegression

TYPE_WEIGHT = {
    "AADHAAR": 20,
    "PAN": 18,
    "PHONE": 10,
    "ADDRESS": 10,
    "EMAIL": 6,
    "DOB": 6,
    "NAME": 4,
}

HIGH_RISK_TYPES = {"AADHAAR", "PAN"}
MEDIUM_RISK_TYPES = {"PHONE", "ADDRESS"}
LOW_RISK_TYPES = {"EMAIL", "DOB", "NAME"}

# Extra points added when multiple high-risk identifiers co-occur -
# this is what drives "combination" risk mentioned in the infographic
# (e.g. Aadhaar + PAN + Phone + Address together = high identity-fraud risk).
COMBINATION_BONUS_PER_PAIR = 6


def _bucket(entity_type: str) -> str:
    if entity_type in HIGH_RISK_TYPES:
        return "high"
    if entity_type in MEDIUM_RISK_TYPES:
        return "medium"
    return "low"


def _train_bucket_classifier() -> LogisticRegression:
    """Synthetic training data: [pii_count, high_count, medium_count, low_count] -> label.
    0=LOW, 1=MEDIUM, 2=HIGH. Trained once at import time (module 4's 'AI' scoring layer)."""
    X, y = [], []
    rng = np.random.default_rng(42)
    for _ in range(400):
        high = rng.integers(0, 5)
        medium = rng.integers(0, 5)
        low = rng.integers(0, 6)
        total = high + medium + low
        if high >= 2 or (high >= 1 and medium >= 2):
            label = 2
        elif high == 1 or medium >= 2 or total >= 5:
            label = 1
        else:
            label = 0
        X.append([total, high, medium, low])
        y.append(label)
    model = LogisticRegression(max_iter=1000)
    model.fit(np.array(X), np.array(y))
    return model


_BUCKET_MODEL = _train_bucket_classifier()
_LABELS = {0: "LOW RISK", 1: "MEDIUM RISK", 2: "HIGH RISK"}


def assess(entities: list[dict]) -> dict:
    high = medium = low = 0
    score = 0
    risk_factors = []

    for e in entities:
        bucket = _bucket(e["entity_type"])
        if bucket == "high":
            high += 1
            risk_factors.append(e["entity_type"])
        elif bucket == "medium":
            medium += 1
            risk_factors.append(e["entity_type"])
        else:
            low += 1
        score += TYPE_WEIGHT.get(e["entity_type"], 3)

    distinct_high_types = len({e["entity_type"] for e in entities if _bucket(e["entity_type"]) == "high"})
    distinct_medium_types = len({e["entity_type"] for e in entities if _bucket(e["entity_type"]) == "medium"})
    combo_types = distinct_high_types + distinct_medium_types
    if combo_types > 1:
        score += (combo_types - 1) * COMBINATION_BONUS_PER_PAIR

    score = int(min(score, 100))
    total = high + medium + low

    bucket_idx = _BUCKET_MODEL.predict(np.array([[total, high, medium, low]]))[0]
    label = _LABELS[int(bucket_idx)]

    return {
        "risk_score": score,
        "risk_label": label,
        "pii_count": total,
        "high_risk_items": high,
        "medium_risk_items": medium,
        "low_risk_items": low,
        "risk_factors": sorted(set(risk_factors)),
    }
