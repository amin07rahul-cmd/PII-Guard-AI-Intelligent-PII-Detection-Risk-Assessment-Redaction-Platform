"""
Module 6: Output & Report - generates the PII Detection Report
(PII summary, risk score, redaction details, pages affected) and
exports it as PDF, JSON or CSV.
"""
import csv
import io
import json

import pandas as pd
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle


def build_report_dict(document, risk, redaction, entities: list[dict]) -> dict:
    pages_affected = sorted({e.get("page_number", 1) for e in entities}) or [1]
    return {
        "document_id": document.id,
        "filename": document.filename,
        "language": document.language,
        "pii_summary": {
            "total_pii_found": len(entities),
            "by_type": pd.Series([e["entity_type"] for e in entities]).value_counts().to_dict() if entities else {},
        },
        "risk_score": risk["risk_score"] if risk else None,
        "risk_label": risk["risk_label"] if risk else None,
        "risk_factors": risk["risk_factors"] if risk else [],
        "redaction_details": {
            "mode": redaction.mode if redaction else None,
            "pii_found_initial": redaction.pii_found_initial if redaction else None,
            "pii_after_redaction": redaction.pii_after_redaction if redaction else None,
            "redaction_accuracy": redaction.redaction_accuracy if redaction else None,
            "verification_status": redaction.verification_status if redaction else "PENDING",
        },
        "pages_affected": pages_affected,
        "entities": entities,
    }


def to_json_bytes(report: dict) -> bytes:
    return json.dumps(report, indent=2, default=str).encode("utf-8")


def to_csv_bytes(report: dict) -> bytes:
    buf = io.StringIO()
    writer = csv.writer(buf)
    writer.writerow(["entity_type", "value", "risk_level", "confidence", "page_number", "source"])
    for e in report["entities"]:
        writer.writerow([e["entity_type"], e["value"], e["risk_level"], e["confidence"],
                          e.get("page_number", 1), e.get("source", "")])
    return buf.getvalue().encode("utf-8")


def to_pdf_bytes(report: dict) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    story = [
        Paragraph("PII Detection & Risk Report", styles["Title"]),
        Spacer(1, 12),
        Paragraph(f"Document: {report['filename']}", styles["Normal"]),
        Paragraph(f"Language: {report['language']}", styles["Normal"]),
        Paragraph(f"Risk Score: {report['risk_score']}/100 &nbsp;&nbsp; ({report['risk_label']})", styles["Normal"]),
        Paragraph(f"Total PII found: {report['pii_summary']['total_pii_found']}", styles["Normal"]),
        Paragraph(f"Risk factors: {', '.join(report['risk_factors']) or 'None'}", styles["Normal"]),
        Paragraph(f"Redaction mode: {report['redaction_details']['mode']}", styles["Normal"]),
        Paragraph(f"Verification: {report['redaction_details']['verification_status']}", styles["Normal"]),
        Spacer(1, 16),
    ]

    if report["entities"]:
        data = [["Type", "Value", "Risk", "Page"]]
        for e in report["entities"]:
            data.append([e["entity_type"], e["value"], e["risk_level"], str(e.get("page_number", 1))])
        table = Table(data, hAlign="LEFT")
        table.setStyle(TableStyle([
            ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1E3A5F")),
            ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
            ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
            ("FONTSIZE", (0, 0), (-1, -1), 9),
        ]))
        story.append(table)

    doc.build(story)
    return buf.getvalue()
