"""
Ties together modules 1-4 (input -> processing -> PII detection -> risk
assessment) for a single uploaded document.
"""
from app.models import Document, PIIEntity, RiskAssessment
from app.services import ocr_service, pii_detector, risk_engine
from app.routers.alerts import raise_alert


def extract_text_for_document(document: Document, raw_bytes: bytes) -> tuple[str, bool]:
    """Returns (text, ocr_used)."""
    if ocr_service.is_image_file(document.filename):
        text = ocr_service.extract_text(raw_bytes, language=document.language or "en")
        return text, True
    # For non-image types (docx/xlsx/pdf/csv/db-text) the caller is expected to
    # have already produced plain text via the relevant extractor before saving
    # bytes here; this keeps the OCR dependency isolated to true images/scans.
    try:
        return raw_bytes.decode("utf-8", errors="ignore"), False
    except Exception:
        return "", False


def run_pipeline(db, document: Document, raw_bytes: bytes) -> RiskAssessment:
    document.status = "processing"
    text, ocr_used = extract_text_for_document(document, raw_bytes)
    document.ocr_used = ocr_used
    document.extracted_text = text

    entities, language = pii_detector.detect_pii(text, language=document.language)
    document.language = language

    for e in entities:
        db.add(PIIEntity(document_id=document.id, page_number=1, **e))

    risk = risk_engine.assess(entities)
    risk_row = RiskAssessment(document_id=document.id, **risk)
    db.add(risk_row)

    document.status = "detected"
    db.commit()
    db.refresh(risk_row)

    if risk_row.risk_label == "HIGH RISK":
        raise_alert(document.id, "critical",
                    f"'{document.filename}' scored {risk_row.risk_score}/100 - HIGH RISK "
                    f"({', '.join(risk_row.risk_factors or [])})")

    return risk_row
