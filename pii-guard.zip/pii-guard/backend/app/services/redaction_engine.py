"""
Module 5: Smart Redaction Engine.
Supports Full Redaction, Partial Masking, "Show Last 4" and Custom Masking,
applied per-PII-type according to an organization redaction policy
(module 5's "Policy Based Redaction").
Works on both extracted text and on raster images (using OpenCV to draw
black boxes over OCR word bounding boxes for scanned/handwritten PII,
module 8).
"""
import io
import re

import cv2
import numpy as np

MODES = ("full", "partial", "show_last4", "custom_mask")


def _mask_value(value: str, mode: str) -> str:
    clean = value.strip()
    if mode == "full":
        return "█" * len(clean)
    if mode == "show_last4":
        visible = clean[-4:] if len(clean) > 4 else clean
        return "X" * max(len(clean) - len(visible), 0) + visible
    if mode == "partial":
        # keep first and last visible token/segment, mask the middle
        parts = re.split(r"(\s+)", clean)
        if len(parts) <= 1:
            half = len(clean) // 2
            return clean[:2] + "X" * max(len(clean) - 4, 0) + clean[-2:] if len(clean) > 4 else "X" * len(clean)
        masked = []
        for i, p in enumerate(parts):
            if p.strip() == "":
                masked.append(p)
            elif i == 0 or i == len(parts) - 1:
                masked.append(p)
            else:
                masked.append("X" * len(p))
        return "".join(masked)
    if mode == "custom_mask":
        # e.g. email -> ra***@gmail.com style: keep 2 leading chars of local part
        if "@" in clean:
            local, _, domain = clean.partition("@")
            keep = local[:2]
            return f"{keep}{'*' * max(len(local) - 2, 1)}@{domain}"
        if len(clean) > 4:
            return clean[:2] + "*" * (len(clean) - 4) + clean[-2:]
        return "*" * len(clean)
    return "█" * len(clean)


def redact_text(text: str, entities: list[dict], policy_by_type: dict[str, str],
                 default_mode: str = "full", entity_types: list[str] | None = None) -> str:
    """Replace every detected PII value in the raw text according to the policy."""
    redacted = text
    # sort by length desc to avoid partial-substring collisions
    values = sorted({(e["entity_type"], e["value"]) for e in entities}, key=lambda t: len(t[1]), reverse=True)
    for etype, value in values:
        if entity_types and etype not in entity_types:
            continue
        mode = policy_by_type.get(etype, default_mode)
        redacted = redacted.replace(value, _mask_value(value, mode))
    return redacted


def redact_image(image_bytes: bytes, words_with_boxes: list[dict], pii_values: set[str]) -> bytes:
    """Draws solid black boxes over image regions whose OCR word text matches a
    detected PII value (module 8: bounding boxes on detected PII)."""
    arr = np.frombuffer(image_bytes, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    pii_tokens = set()
    for v in pii_values:
        pii_tokens.update(v.split())

    for w in words_with_boxes:
        if w["text"] in pii_tokens or any(w["text"] in v for v in pii_values):
            x, y, ww, hh = w["left"], w["top"], w["width"], w["height"]
            cv2.rectangle(img, (x, y), (x + ww, y + hh), (0, 0, 0), thickness=-1)

    success, buf = cv2.imencode(".png", img)
    if not success:
        raise RuntimeError("Failed to encode redacted image")
    return buf.tobytes()


def default_policy() -> dict[str, str]:
    return {
        "AADHAAR": "full",
        "PAN": "partial",
        "PHONE": "show_last4",
        "EMAIL": "custom_mask",
        "ADDRESS": "partial",
        "DOB": "full",
        "NAME": "partial",
    }
