"""
Module 10: Privacy Copilot (AI Assistant).
Answers natural-language questions about scanned documents, e.g.
"Find all documents with Aadhaar numbers" or "Why is this document high risk?"

Uses a Hugging Face zero-shot-classification pipeline to route the question
to an intent, then answers by querying Postgres/Mongo directly (grounded
answers only - it never invents PII values). Falls back to a regex-based
intent matcher if the transformer model cannot be loaded (e.g. no network
access to the Hugging Face hub), so the assistant keeps working offline.
"""
import re
from functools import lru_cache

INTENTS = [
    "find documents containing a specific PII type",
    "explain why a document is high risk",
    "summarize PII found in a document",
    "general privacy question",
]

ENTITY_KEYWORDS = {
    "AADHAAR": ["aadhaar", "aadhar", "uidai"],
    "PAN": ["pan", "pan card", "pan number"],
    "PHONE": ["phone", "mobile", "contact number"],
    "EMAIL": ["email", "e-mail", "mail id"],
    "ADDRESS": ["address", "location"],
    "DOB": ["dob", "date of birth", "birthday"],
    "NAME": ["name"],
}


@lru_cache(maxsize=1)
def _classifier():
    try:
        from transformers import pipeline
        return pipeline("zero-shot-classification", model="facebook/bart-large-mnli")
    except Exception:
        return None


def _classify_intent(question: str) -> str:
    clf = _classifier()
    if clf is not None:
        try:
            result = clf(question, INTENTS)
            return result["labels"][0]
        except Exception:
            pass
    # Regex fallback
    q = question.lower()
    if re.search(r"\bfind|which documents|list documents\b", q):
        return "find documents containing a specific PII type"
    if re.search(r"\bwhy\b.*\b(risk|risky|high)\b", q):
        return "explain why a document is high risk"
    if re.search(r"\bsummar", q):
        return "summarize PII found in a document"
    return "general privacy question"


def _extract_entity_type(question: str) -> str | None:
    q = question.lower()
    for etype, keywords in ENTITY_KEYWORDS.items():
        if any(kw in q for kw in keywords):
            return etype
    return None


def answer_question(question: str, db, document_id: str | None = None) -> dict:
    """db: SQLAlchemy session. Returns {answer, matched_documents, data}."""
    from app.models import Document, PIIEntity, RiskAssessment

    intent = _classify_intent(question)

    if intent == "find documents containing a specific PII type":
        etype = _extract_entity_type(question)
        if not etype:
            return {"answer": "Please specify a PII type, e.g. Aadhaar, PAN, phone or email.",
                    "matched_documents": [], "data": None}
        rows = (db.query(PIIEntity.document_id).filter(PIIEntity.entity_type == etype)
                .distinct().all())
        doc_ids = [r[0] for r in rows]
        count = len(doc_ids)
        return {
            "answer": f"Found {count} document{'s' if count != 1 else ''} containing {etype}.",
            "matched_documents": doc_ids,
            "data": {"entity_type": etype, "count": count},
        }

    if intent == "explain why a document is high risk":
        if not document_id:
            return {"answer": "Tell me which document you mean, or open it first.",
                    "matched_documents": [], "data": None}
        risk = db.query(RiskAssessment).filter(RiskAssessment.document_id == document_id).first()
        if not risk:
            return {"answer": "This document hasn't been risk-assessed yet.",
                    "matched_documents": [document_id], "data": None}
        factors = ", ".join(risk.risk_factors or []) or "no high/medium risk identifiers"
        answer = (f"It scored {risk.risk_score}/100 ({risk.risk_label}) because it contains "
                  f"{factors} - {risk.high_risk_items} high-risk and {risk.medium_risk_items} "
                  f"medium-risk identifiers, which together raise identity-fraud exposure.")
        return {"answer": answer, "matched_documents": [document_id], "data": None}

    if intent == "summarize PII found in a document":
        if not document_id:
            return {"answer": "Tell me which document you'd like summarized.",
                    "matched_documents": [], "data": None}
        entities = db.query(PIIEntity).filter(PIIEntity.document_id == document_id).all()
        by_type = {}
        for e in entities:
            by_type[e.entity_type] = by_type.get(e.entity_type, 0) + 1
        summary = ", ".join(f"{v} {k}" for k, v in by_type.items()) or "no PII"
        return {"answer": f"This document contains {summary}.",
                "matched_documents": [document_id], "data": by_type}

    return {
        "answer": ("I can help you find documents by PII type, explain a document's risk score, "
                   "or summarize the PII found in a document. Try asking something like "
                   "\"Find all documents with Aadhaar numbers\"."),
        "matched_documents": [],
        "data": None,
    }
