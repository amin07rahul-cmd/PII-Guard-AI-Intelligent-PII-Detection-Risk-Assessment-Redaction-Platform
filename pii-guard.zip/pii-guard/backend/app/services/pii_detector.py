"""
Module 3: PII Detection (AI + NLP) - detects and classifies Personally
Identifiable Information using spaCy NER combined with regex validators
for India-specific identifier formats (Aadhaar, PAN, phone, pincode).

Module 7: Multilingual PII detection - language is auto-detected with
langdetect; regex-based identifiers (Aadhaar/PAN/phone/email) are
language-independent by design, and spaCy's English model additionally
picks up transliterated / English-script names. Unicode-script matching
gives best-effort name/address recall for Devanagari, Tamil, Bengali and
Kannada scripts.
"""
import re
from functools import lru_cache

import spacy
from langdetect import detect, LangDetectException

from app.config import settings

# ---------------------------------------------------------------------------
# Regex validators for Indian PII formats
# ---------------------------------------------------------------------------
PATTERNS = {
    "AADHAAR": re.compile(r"\b\d{4}\s?\d{4}\s?\d{4}\b"),
    "PAN": re.compile(r"\b[A-Z]{5}[0-9]{4}[A-Z]\b"),
    "PHONE": re.compile(r"\b(?:\+91[\s-]?)?[6-9]\d{9}\b"),
    "EMAIL": re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b"),
    "DOB": re.compile(r"\b\d{2}[/-]\d{2}[/-]\d{4}\b"),
    "PINCODE": re.compile(r"\b\d{6}\b"),
}

# Words that hint an address line is nearby (used to build an ADDRESS entity)
ADDRESS_HINTS = re.compile(
    r"\b(road|rd|street|st|nagar|colony|sector|lane|apartment|flat|building|"
    r"village|taluka|district|city|state|pin|pincode)\b", re.IGNORECASE)

# Unicode script ranges used for best-effort multilingual name detection
SCRIPT_RANGES = {
    "hi": (0x0900, 0x097F),  # Devanagari (Hindi/Marathi)
    "mr": (0x0900, 0x097F),
    "ta": (0x0B80, 0x0BFF),  # Tamil
    "bn": (0x0980, 0x09FF),  # Bengali
    "kn": (0x0C80, 0x0CFF),  # Kannada
}

RISK_LEVEL_BY_TYPE = {
    "AADHAAR": "high",
    "PAN": "high",
    "PHONE": "medium",
    "ADDRESS": "medium",
    "EMAIL": "low",
    "DOB": "low",
    "NAME": "low",
    "PINCODE": "low",
}


@lru_cache(maxsize=1)
def _nlp():
    return spacy.load(settings.SPACY_MODEL_EN)


def detect_language(text: str) -> str:
    if not text or not text.strip():
        return "en"
    try:
        code = detect(text)
    except LangDetectException:
        return "en"
    return code if code in ("en", "hi", "mr", "ta", "bn", "kn") else "en"


def _regex_entities(text: str) -> list[dict]:
    entities = []
    for etype, pattern in PATTERNS.items():
        if etype == "PINCODE":
            continue  # only used as an address-strength signal, not reported standalone
        for match in pattern.finditer(text):
            entities.append({
                "entity_type": etype,
                "value": match.group().strip(),
                "risk_level": RISK_LEVEL_BY_TYPE[etype],
                "confidence": 0.95,
                "source": "regex",
            })
    return entities


def _address_entities(text: str) -> list[dict]:
    entities = []
    for line in text.split("\n"):
        if ADDRESS_HINTS.search(line) or PATTERNS["PINCODE"].search(line):
            cleaned = line.strip()
            if cleaned:
                entities.append({
                    "entity_type": "ADDRESS",
                    "value": cleaned,
                    "risk_level": RISK_LEVEL_BY_TYPE["ADDRESS"],
                    "confidence": 0.75,
                    "source": "regex",
                })
    return entities


def _spacy_entities(text: str) -> list[dict]:
    entities = []
    doc = _nlp()(text)
    for ent in doc.ents:
        if ent.label_ == "PERSON":
            entities.append({
                "entity_type": "NAME",
                "value": ent.text.strip(),
                "risk_level": RISK_LEVEL_BY_TYPE["NAME"],
                "confidence": 0.85,
                "source": "spacy_ner",
            })
        elif ent.label_ in ("GPE", "LOC", "FAC"):
            entities.append({
                "entity_type": "ADDRESS",
                "value": ent.text.strip(),
                "risk_level": RISK_LEVEL_BY_TYPE["ADDRESS"],
                "confidence": 0.6,
                "source": "spacy_ner",
            })
    return entities


def _script_based_name_candidates(text: str, language: str) -> list[dict]:
    """Best-effort extraction of contiguous non-English-script tokens as
    name/address candidates for Hindi/Marathi/Tamil/Bengali/Kannada text."""
    if language not in SCRIPT_RANGES:
        return []
    lo, hi = SCRIPT_RANGES[language]
    tokens = re.findall(r"[^\s]+", text)
    entities = []
    for tok in tokens:
        if len(tok) < 2:
            continue
        script_chars = sum(1 for ch in tok if lo <= ord(ch) <= hi)
        if script_chars / max(len(tok), 1) > 0.6:
            entities.append({
                "entity_type": "NAME",
                "value": tok,
                "risk_level": RISK_LEVEL_BY_TYPE["NAME"],
                "confidence": 0.5,
                "source": f"script_{language}",
            })
    return entities


def _dedupe(entities: list[dict]) -> list[dict]:
    seen = set()
    result = []
    for e in entities:
        key = (e["entity_type"], e["value"])
        if key not in seen:
            seen.add(key)
            result.append(e)
    return result


def detect_pii(text: str, language: str | None = None) -> tuple[list[dict], str]:
    """Returns (entities, detected_language)."""
    lang = language or detect_language(text)
    entities = _regex_entities(text)
    entities += _address_entities(text)
    if lang == "en":
        entities += _spacy_entities(text)
    else:
        entities += _script_based_name_candidates(text, lang)
        # Still run regex-independent English NER as a fallback for mixed-script docs
        entities += _spacy_entities(text)
    return _dedupe(entities), lang
