"""
Module 2: Document processing - OCR, handwriting recognition (Tesseract handwriting
config), image enhancement, noise removal, layout analysis.
Module 8: Image & handwritten PII - returns word-level bounding boxes so detected
PII can be highlighted / redacted directly on the image.
"""
import cv2
import numpy as np
import pytesseract
from PIL import Image

from app.config import settings

if settings.TESSERACT_CMD:
    pytesseract.pytesseract.tesseract_cmd = settings.TESSERACT_CMD

# Tesseract language codes for the multilingual module (7)
LANG_MAP = {
    "en": "eng",
    "hi": "hin",
    "mr": "mar",
    "ta": "tam",
    "bn": "ben",
    "kn": "kan",
}


def _enhance_image(img: np.ndarray) -> np.ndarray:
    """Image Enhancement + Noise Removal steps from module 2."""
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    denoised = cv2.fastNlMeansDenoising(gray, h=10)
    # Adaptive threshold improves OCR on scanned / uneven-lighting documents
    thresh = cv2.adaptiveThreshold(
        denoised, 255, cv2.ADAPTIVE_THRESH_GAUSSIAN_C, cv2.THRESH_BINARY, 31, 11
    )
    return thresh


def _deskew(img: np.ndarray) -> np.ndarray:
    """Layout & structure analysis step - corrects skewed scans."""
    coords = np.column_stack(np.where(img < 255))
    if coords.size == 0:
        return img
    angle = cv2.minAreaRect(coords)[-1]
    angle = -(90 + angle) if angle < -45 else -angle
    (h, w) = img.shape[:2]
    center = (w // 2, h // 2)
    m = cv2.getRotationMatrix2D(center, angle, 1.0)
    return cv2.warpAffine(img, m, (w, h), flags=cv2.INTER_CUBIC,
                           borderMode=cv2.BORDER_REPLICATE)


def preprocess(image_bytes: bytes) -> np.ndarray:
    arr = np.frombuffer(image_bytes, dtype=np.uint8)
    img = cv2.imdecode(arr, cv2.IMREAD_COLOR)
    enhanced = _enhance_image(img)
    return _deskew(enhanced)


def extract_text(image_bytes: bytes, language: str = "en", handwritten: bool = False) -> str:
    """OCR (Text Extraction) + Handwriting Recognition."""
    processed = preprocess(image_bytes)
    pil_img = Image.fromarray(processed)
    lang = LANG_MAP.get(language, "eng")
    # PSM 6: assume a uniform block of text - works well for forms/letters.
    # OEM 1 (LSTM) generally gives the best handwriting recognition results available in Tesseract.
    config = f"--oem 1 --psm 6"
    return pytesseract.image_to_string(pil_img, lang=lang, config=config)


def extract_words_with_boxes(image_bytes: bytes, language: str = "en") -> list[dict]:
    """
    Returns word-level bounding boxes: [{text, left, top, width, height, conf}]
    Used to draw redaction boxes directly over PII found in scanned/handwritten
    documents (module 8) and to power the smart redaction engine (module 5) on images.
    """
    processed = preprocess(image_bytes)
    pil_img = Image.fromarray(processed)
    lang = LANG_MAP.get(language, "eng")
    data = pytesseract.image_to_data(pil_img, lang=lang, output_type=pytesseract.Output.DICT,
                                      config="--oem 1 --psm 6")
    words = []
    for i, text in enumerate(data["text"]):
        if text.strip():
            words.append({
                "text": text,
                "left": data["left"][i],
                "top": data["top"][i],
                "width": data["width"][i],
                "height": data["height"][i],
                "conf": float(data["conf"][i]) if data["conf"][i] not in ("-1", "") else 0.0,
            })
    return words


def is_image_file(filename: str) -> bool:
    return filename.lower().endswith((".png", ".jpg", ".jpeg", ".tif", ".tiff", ".bmp"))
