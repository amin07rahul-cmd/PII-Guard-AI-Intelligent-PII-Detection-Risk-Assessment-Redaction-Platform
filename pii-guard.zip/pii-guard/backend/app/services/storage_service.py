"""
Module 1/6: handles saving uploaded originals and redacted outputs.
Backed by local disk by default, or AWS S3 (boto3) when STORAGE_BACKEND=s3.
"""
import os
import uuid

from app.config import settings

if settings.STORAGE_BACKEND == "s3":
    import boto3
    _s3 = boto3.client(
        "s3",
        aws_access_key_id=settings.AWS_ACCESS_KEY_ID,
        aws_secret_access_key=settings.AWS_SECRET_ACCESS_KEY,
        region_name=settings.AWS_REGION,
    )
else:
    os.makedirs(settings.LOCAL_STORAGE_DIR, exist_ok=True)


def _new_key(filename: str) -> str:
    ext = os.path.splitext(filename)[1]
    return f"{uuid.uuid4().hex}{ext}"


def save_bytes(data: bytes, filename: str) -> str:
    """Persist raw bytes, return a storage path/key that can be resolved later."""
    key = _new_key(filename)
    if settings.STORAGE_BACKEND == "s3":
        _s3.put_object(Bucket=settings.S3_BUCKET, Key=key, Body=data)
        return f"s3://{settings.S3_BUCKET}/{key}"
    path = os.path.join(settings.LOCAL_STORAGE_DIR, key)
    with open(path, "wb") as f:
        f.write(data)
    return path


def read_bytes(storage_path: str) -> bytes:
    if storage_path.startswith("s3://"):
        _, _, rest = storage_path.partition("s3://")
        bucket, _, key = rest.partition("/")
        obj = _s3.get_object(Bucket=bucket, Key=key)
        return obj["Body"].read()
    with open(storage_path, "rb") as f:
        return f.read()


def resolve_url(storage_path: str) -> str:
    """Return a URL/path the frontend can use to fetch the file via the API."""
    if storage_path.startswith("s3://"):
        _, _, rest = storage_path.partition("s3://")
        bucket, _, key = rest.partition("/")
        return _s3.generate_presigned_url(
            "get_object", Params={"Bucket": bucket, "Key": key}, ExpiresIn=3600
        )
    return f"/api/files/{os.path.basename(storage_path)}"
