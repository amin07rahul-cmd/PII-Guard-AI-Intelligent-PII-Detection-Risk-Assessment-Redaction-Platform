from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import Base, engine
from app.routers import auth, documents, redaction, reports, copilot, analytics, alerts, files

Base.metadata.create_all(bind=engine)

app = FastAPI(title=settings.APP_NAME, version="1.0.0")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router)
app.include_router(documents.router)
app.include_router(redaction.router)
app.include_router(reports.router)
app.include_router(copilot.router)
app.include_router(analytics.router)
app.include_router(alerts.router)
app.include_router(files.router)


@app.get("/api/health")
def health():
    return {"status": "ok", "app": settings.APP_NAME}
