from pymongo import MongoClient

from app.config import settings

_client = MongoClient(settings.MONGO_URL)
mongo_db = _client[settings.MONGO_DB]

# Collections
reports_collection = mongo_db["pii_reports"]          # module 6: PII detection report (JSON export)
copilot_logs_collection = mongo_db["copilot_logs"]    # module 10: privacy copilot Q&A history
alerts_collection = mongo_db["alerts"]                # module 12: real-time alerts
analytics_events_collection = mongo_db["analytics_events"]  # module 11: dashboard events
